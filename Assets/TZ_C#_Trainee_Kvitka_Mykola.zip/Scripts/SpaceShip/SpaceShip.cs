using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpaceShip : MonoBehaviour
{
    [SerializeField] private List<Module> _modules;
    private float _currentHealth = 0;
    private float _maxHealth = 0;
    private int _currentDamage;
    
    
}
