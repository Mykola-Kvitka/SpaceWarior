using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Module
{
    private double _price;
    private double _strength;
    
    
}
