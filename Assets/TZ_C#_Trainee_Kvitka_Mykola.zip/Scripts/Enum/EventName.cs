using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum EventName 
{
    GameOver,
    Battle,
    AsteroidMining,
    PlanetMining,
    SellOre,
    BuyEnergy
}
