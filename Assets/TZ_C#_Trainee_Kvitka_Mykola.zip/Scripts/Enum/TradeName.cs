using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum TradeName
{
    Buy,
    Sell,
    BuyWithDelivery
}
