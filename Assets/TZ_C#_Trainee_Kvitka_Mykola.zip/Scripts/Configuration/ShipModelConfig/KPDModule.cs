using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Data", menuName = "ScriptableObjects/SpaceShip/KPDModule", order = 3)]
public class KPDModule : ModuleConfigs
{
}
